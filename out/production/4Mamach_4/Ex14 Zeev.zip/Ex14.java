public class Ex14 {

    /**
     * function calculates and returns maximal drop between two peaks
     * @param a int array
     * @return int - maximal drop between two peaks
     *
     * complexity is O(n)
     * we will iterate the whole array once, and it depends on the array length
     */
    public static int maximalDrop (int [] a){

        if (a.length <=1)
            return 0;

        int max = a[0];
        int min = a[0];
        int drop = 0;
        for (int i = 0 ; i < a.length ; i++ )
        {
            if (a[i] < min)
                min = a[i];
            if (max - min > drop) {
                drop = max - min;
            }
            if (a[i] > max)
            {
                max = a[i];
                min = a[i];
            }
        }

        return drop;
    }//end of maximalDrop

    /**
     * function that finds if there is a sink in the matrix
     * a sink is defined as the row k filled with zeroes and the column k filled with ones (except [mat[k][k]
     * that is also zero)
     * @param mat - int matrix with nXn dimentions filled with 1 or 0
     * @return int - number of col/row that is sink, otherwise returns -1 (if no sink in mat)
     *
     * * complexity is O(n2)
     * in the worst case the function will have to iterate though almost all the
     * array when it does not have a sink
     */
    public static int isSink (int [][] mat){
        int sink = -1;
        int len = mat.length;
        /*
        if (len == 1)
        {
            if (mat[0][0] == 0)
                return 0;
            else
                return -1;
        }*/
        boolean flag = false;

        for (int i = 0 ; !flag && i < len ; i++)
        {
            flag = true;
            for (int j = 0 ;flag && j < len ; j++)
            {
                if ((mat [i][j] == 0 && mat [j][i] == 1) || (i == j && mat [j][i] == 0))
                {
                    flag = true;
                    sink = i;
                }
                else
                {
                    flag = false;
                    sink = -1;
                }
            }
        }

        return sink;
    }////end of isSink



    /**
     * wrapper for the other size function
     * function recieves a boolean 2d array and a position. (it makes a copy of the array)
     * and returns the size of the stain
     * in case x,y point to a clean position or x,y is out of array bounderies return 0
     * @param mat 2d boolean matrix true indicates stain
     * @param x - int, x position
     * @param y - int, y position
     * @return - size of the stain
     */
    public static int size (boolean[][] mat, int x, int y) {
        //copy of mat
        boolean[][] copy = new boolean[mat.length][mat[0].length];
        copy = CopyArray(copy, mat.length-1, mat[0].length-1, mat);

        //overloading of size
        int size = size(x,y, copy);

        return size;

    }//end of Size

    /**
     * function receives a boolean 2d array and a position and returns the size of the stain
     * in case x,y point to a clean position or x,y is out of array bounderies return 0
     * @param x - int, x position
     * @param y - int, y position
     * @param copy 2d boolean matrix true indicates stain
     * @return - size of the stain
     */
    private static int size (int x, int y,boolean[][] copy) {
        if (x < copy.length && y < copy[0].length && x >= 0 && y >= 0 && copy[x][y]) {
            copy [x][y] = false;
            return 1 + size(x + 1, y,copy) + size(x - 1, y,copy) + size(x, y + 1,copy) + size(x, y - 1,copy);
        }
        else {
            return 0;
        }
    }//end of Size_overload

    /**
     * private function to make a boolean 2d array recursively
     * @param copy 2d array in the size of the original. any value will be overwritten
     * @param row - number of row in the original / copy array
     * @param column number of columns in the original / copy array
     * @param orig - 2d boolean array, original
     */
    private static boolean[][] CopyArray(boolean [][] copy,int row,int column, boolean[][] orig)
    {
        if (row != 0 || column!=0) {
            copy[row][column] = orig[row][column];
            if (column == 0)
                CopyArray(copy, row - 1, copy[0].length - 1, orig);
            else
                CopyArray(copy, row, column - 1, orig);
        }
        copy[0][0] = orig[0][0];
        return copy;

    }


    /**
     * function finds out if two array`s a a permutation of each other
     * if arrays have same length, same sum and same mult they have the same numbers
     * @param a int array
     * @param b int array
     * @return return True if arrays are permutation of each other
     */
    public static boolean isPermutation (int [] a, int [] b){
        //my flag
        boolean per = false;
        int sumA = 0, sumB = 0, multA=0, multB=0;

        //can be permutation only if same length array
        if (a.length == b.length) {
            //if same lengh multiplication and addition of all numbers should be same
            if (a.length != 0 && b.length != 0) {
                multA = multRec(a, 0);
                sumA = addRec(a, 0);
                multB = multRec(b, 0);
                sumB = addRec(b, 0);
                if (multA == multB && sumA == sumB)
                    per = true;
                else
                    per = false;
            }
            else
                per = true;
        }
        return per;

    }

    /**
     * private method that multiplies all numbers in int array and returns an answer recursively
     * @param intArr - int arr
     * @param index - the current index of the array
     * @return - int - the multiplication of all numbers in arr
     */
    private static int multRec (int[] intArr, int index){
        if (index != intArr.length)
        {
            return intArr[index] * multRec(intArr,index+1);
        }
        return 1;
    }//end of multRec

    /**
     * private method that adds up all numbers in int array and returns an answer recursively
     * @param intArr - int arr
     * @param index - the current index of the array
     * @return - int - the addition of all numbers in arr
     */
    private static int addRec (int[] intArr, int index){
        if (index != intArr.length)
        {
            return intArr[index] + addRec(intArr,index+1);
        }
        return 0;
    }//end of addRec

}//end of Ex14
